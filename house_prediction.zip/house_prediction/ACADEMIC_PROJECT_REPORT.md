# Academic Project Report
# HOUSE RENTAL PRICE PREDICTION USING MACHINE LEARNING

**Academic Degree / Department:** Department of Computer Science & Engineering / Data Science  
**Subject:** Applied Machine Learning & Predictive Analytics Capstone  
**Dataset Source:** Real Indian House Rent Prediction Dataset (Kaggle - Sourav Banerjee)  
**Programming Language:** Python 3.10+  
**Target Variable:** Monthly Rent in Indian Rupees (INR / ₹)  

---

## Table of Contents
1. [Abstract](#1-abstract)
2. [Introduction](#2-introduction)
3. [Problem Statement](#3-problem-statement)
4. [Objectives](#4-objectives)
5. [Dataset Collection and Source](#5-dataset-collection-and-source)
6. [Dataset Description](#6-dataset-description)
7. [Data Preprocessing](#7-data-preprocessing)
8. [Exploratory Data Analysis (EDA)](#8-exploratory-data-analysis-eda)
9. [Data Visualization](#9-data-visualization)
10. [Feature Engineering](#10-feature-engineering)
11. [Machine Learning Algorithms](#11-machine-learning-algorithms)
12. [Model Training & Leakage Prevention](#12-model-training--leakage-prevention)
13. [Model Prediction System](#13-model-prediction-system)
14. [Performance Evaluation Metrics](#14-performance-evaluation-metrics)
15. [Model Comparison & Benchmark Results](#15-model-comparison--benchmark-results)
16. [Results and Discussion](#16-results-and-discussion)
17. [Conclusion](#17-conclusion)
18. [Future Scope](#18-future-scope)
19. [References](#19-references)

---

## 1. Abstract

Determining fair residential rental rates in India’s metropolitan hubs (**Mumbai, Bangalore, Delhi, Hyderabad, Chennai, and Kolkata**) has traditionally been hindered by severe information asymmetry, speculative quoting, and fragmented local brokerage networks. This project develops an end-to-end supervised machine learning regression system to predict fair monthly house rent in Indian Rupees (INR / ₹) based on physical attributes, building characteristics, contract terms, and geographical locations.

Using the authentic Kaggle Indian House Rent Prediction Dataset (4,746 real property listings), we implemented systematic data preprocessing, outlier mitigation, and feature engineering (composite floor parsing and spatial ratios). We trained, cross-validated, and benchmarked four core machine learning algorithms within leakage-free Scikit-Learn pipelines: **Linear Regression (OLS)**, **Decision Tree Regressor (CART)**, **Random Forest Regressor**, and **Gradient Boosting Regressor**.

The **Random Forest Regressor** achieved superior performance with a Coefficient of Determination of **$R^2 = 0.7681$** and a Mean Absolute Error of **₹ 9,527.53** on unseen test data, while **Gradient Boosting** achieved **$R^2 = 0.7671$** and an MAE of **₹ 9,429.02**. The trained model pipeline was serialized using Joblib, and deployed within an interactive, zero-retraining **Streamlit web application** for real-time market rent estimation.

---

## 2. Introduction

Real estate represents one of the largest economic sectors in India. Rapid urbanization, corporate migration to technology corridors, and changing demographics have driven tremendous demand for residential rental housing in tier-1 metropolitan cities. 

However, unlike commercial lease markets or equity investments, residential tenancy pricing in India is largely non-standardized. Rent is subjectively negotiated between landlords, tenants, and intermediaries. A machine learning-driven approach provides a reliable, data-backed baseline for both tenants seeking equitable rates and property owners optimizing occupancy and rental yields.

---

## 3. Problem Statement

Residential rental values in India are governed by complex non-linear interactions across:
- **Spatial Scale**: Square footage, room layout (BHK), and bathroom provisions.
- **Vertical Elevation**: Specific floor level and total building floors.
- **Contractual & Quality Factors**: Furnishing condition, tenant restrictions (bachelors vs. family), and listing intermediary.
- **Geographic Location**: Major metropolitan center and micro-market locality.

### Mathematical Formulation
Let $\mathbf{x} \in \mathbb{R}^d$ denote the $d$-dimensional input feature vector describing a rental property. We seek an empirical estimator $f_\theta: \mathcal{X} \rightarrow \mathbb{R}^+$ parameterized by $\theta$ such that:
$$\hat{y} = f_\theta(\mathbf{x})$$
where $\hat{y}$ minimizes an empirical loss function $\mathcal{L}(y, \hat{y})$ against the ground-truth monthly rent $y \in \mathbb{R}^+$.

---

## 4. Objectives

1. **Ingest and Validate**: Audit the authentic Kaggle Indian House Rent Prediction Dataset (4,746 rows, 12 features).
2. **Data Cleaning & Anomaly Detection**: Audit missing values, detect duplicates, eliminate negative/zero invalid values, and treat extreme recording anomalies (e.g. 35 Lakhs typing error).
3. **Exploratory Data Analysis**: Statistically quantify rental distributions, metropolitan price tiers, and feature correlations.
4. **Data Visualization**: Generate 12 publication-grade figures with legible annotations and professional palettes.
5. **Feature Engineering**: Deconstruct composite floor text into `Floor_Level` and `Total_Floors`, compute spatial ratios (`Size_per_BHK`, `Bathroom_to_BHK`), and normalize target skewness via $\log(1 + y)$.
6. **Model Benchmarking**: Train four regression models under the exact same 80/20 train-test split (`random_state=42`) using Scikit-Learn `ColumnTransformer` pipelines.
7. **Performance Evaluation**: Benchmark models using $R^2$, MAE, MSE, and RMSE, compile `outputs/model_comparison.csv`, and visualize comparisons.
8. **Deployment & Prediction**: Serialize the best pipeline to `models/best_house_rent_model.pkl` and deliver an interactive Streamlit UI (`app.py`).

---

## 5. Dataset Collection and Source

- **Repository**: [Kaggle - House Rent Prediction Dataset](https://www.kaggle.com/datasets/iamsouravbanerjee/house-rent-prediction-dataset)
- **Compiler**: Sourav Banerjee (2022)
- **Data Provenance**: Gathered from prominent Indian real estate portals spanning 6 major urban zones.
- **File Name**: `House_Rent_Dataset.csv` (Located in `dataset/`)
- **Sample Size**: 4,746 rows, 12 initial attributes

---

## 6. Dataset Description

### Attribute Dictionary

| Attribute | Data Type | Machine Learning Role | Detailed Description |
| :--- | :--- | :--- | :--- |
| **`Posted On`** | String / Date | Temporal Indicator | Listing publication date (May – July 2022). |
| **`BHK`** | Integer | Discrete Numerical | Number of Bedrooms, Hall, and Kitchen (1 to 6). |
| **`Rent`** | Integer | **Target Variable ($y$)** | Monthly rental price in Indian Rupees (INR / ₹). |
| **`Size`** | Integer | Continuous Numerical | Property area measured in square feet (sq. ft.). |
| **`Floor`** | String | Composite Categorical | Floor elevation and building floors (e.g., `'1 out of 3'`). |
| **`Area Type`** | Categorical | Nominal Feature | *Super Area*, *Carpet Area*, or *Built Area*. |
| **`Area Locality`**| Categorical | High-Cardinality Nominal | Micro-neighborhood (2,235 unique localities). |
| **`City`** | Categorical | Regional Nominal | Metropolitan city (*Mumbai, Delhi, Bangalore, etc.*). |
| **`Furnishing Status`** | Categorical | Nominal Feature | *Furnished*, *Semi-Furnished*, or *Unfurnished*. |
| **`Tenant Preferred`** | Categorical | Nominal Feature | *Bachelors/Family*, *Bachelors*, or *Family*. |
| **`Bathroom`** | Integer | Discrete Numerical | Number of bathrooms (1 to 10). |
| **`Point of Contact`** | Categorical | Nominal Feature | *Contact Owner*, *Contact Agent*, *Contact Builder*. |

---

## 7. Data Preprocessing

### 7.1 Missing and Duplicate Audit
- **Missing Values**: Executing `df.isnull().sum()` confirmed **0 missing values** across all 12 columns.
- **Duplicate Records**: Auditing with `df.duplicated().sum()` confirmed **0 duplicate listings**.
- **Sanity Checks**: Verified **0 non-positive entries** for `Rent <= 0`, `Size <= 0`, `BHK <= 0`, or `Bathroom <= 0`. Minimum size is 10 sq. ft. and minimum rent is ₹ 1,200.

### 7.2 Outlier Detection and Treatment
Inspection of maximum rental values revealed that record row 1837 contained a 3 BHK, 2,500 sq.ft apartment in Marathahalli, Bangalore listed at **₹ 3,500,000 / month** (35 Lakhs). Market rents in Marathahalli range from ₹ 35,000 to ₹ 50,000; this entry was an obvious broker typing error. 

To maintain statistical generalizability without arbitrary truncation, listings above the **99.9th percentile (₹ 685,100)** were trimmed (5 records removed), producing a clean modeling dataset of **4,741 records**.

### 7.3 Target Variable Transformation
Raw rental prices display extreme positive skewness (**skewness = 4.88**). A logarithmic transformation was applied:
$$y_{\text{train}} = \log(1 + \text{Rent})$$
This reduced skewness to **0.85**, yielding a near-Gaussian distribution that stabilized residual variance and prevented high-rent properties from dominating squared-error loss gradients.

### 7.4 Feature Matrix Dimensionality
`Rent` is strictly isolated as the target vector $\mathbf{y}$ and never included in $\mathbf{X}$. Raw `Posted On` is removed from $\mathbf{X}$ to prevent temporal overfitting. `Area Locality` contains 2,235 unique categorical levels; one-hot encoding this would induce extreme sparsity. Macro-geography is captured cleanly by `City` (6 tiers), while localized quality is captured through `Floor_Level`, `Total_Floors`, and `Size_per_BHK`.

---

## 8. Exploratory Data Analysis (EDA)

Computed directly from actual dataset values:

### 8.1 Metropolitan City Statistics
- **Mumbai** (972 listings): Mean = **₹ 85,321** | Median = **₹ 52,000** | Max = ₹ 1,200,000
- **Delhi** (605 listings): Mean = **₹ 29,462** | Median = **₹ 17,000** | Max = ₹ 530,000
- **Bangalore** (885 listings): Mean = **₹ 21,059** | Median = **₹ 14,000** | Max = ₹ 600,000
- **Chennai** (891 listings): Mean = **₹ 21,614** | Median = **₹ 14,000** | Max = ₹ 600,000
- **Hyderabad** (868 listings): Mean = **₹ 20,555** | Median = **₹ 14,000** | Max = ₹ 400,000
- **Kolkata** (524 listings): Mean = **₹ 11,645** | Median = **₹ 8,500** | Max = ₹ 180,000

### 8.2 BHK and Furnishing Distribution
- **2 BHK** dominates the market (**2,265 listings, 47.8%**), averaging **₹ 22,114**.
- **1 BHK** comprises **1,167 listings (24.6%)**, averaging **₹ 14,139**.
- **3 BHK** comprises **1,098 listings (23.2%)**, jumping sharply to **₹ 55,863**.
- **Furnished** accommodations command an average rent of **₹ 56,110** (a **150% premium** over **Unfurnished** accommodations at **₹ 22,462**).

### 8.3 Correlation Analysis
- **Bathroom Count ($r = 0.60$)** and **Property Size ($r = 0.51$)** have the highest positive correlations with rent.
- Total building floors correlate moderately with rent ($r = 0.50$), indicating higher rental rates in modern high-rise gated societies.

---

## 9. Data Visualization

All 12 graphs were saved in `outputs/graphs/` with titles, axis labels, and annotations:

1. `bar_average_rent_by_city.png`: Bar chart of mean rent across Indian cities.
2. `bar_houses_count_by_city.png`: Listing availability counts across all 6 metropolitan cities.
3. `bar_average_rent_by_bhk.png`: Average rent scaling across 1 to 6 BHK units.
4. `bar_average_rent_by_furnishing.png`: Average rent comparison across Furnished, Semi-Furnished, and Unfurnished.
5. `histogram_rent_distribution.png`: Dual subplots of Raw Right-Skewed Rent vs. Log-Transformed Normal Rent.
6. `scatter_size_vs_rent.png`: Bivariate scatter of square footage vs. monthly rent colored by city.
7. `boxplot_rent_by_city.png`: Box plot showing median and interquartile ranges across cities.
8. `boxplot_rent_by_furnishing.png`: Box plot of rental spread across furnishing tiers.
9. `heatmap_numerical_correlation.png`: Masked upper-triangular Pearson correlation heatmap.
10. `countplot_bhk_distribution.png`: Count plot showing 2 BHK market dominance (47.8%).
11. `bar_average_rent_by_bathrooms.png`: Average rent scaling across bathroom counts.
12. `pairplot_numerical_features.png`: Pairwise KDE scatter distributions of numerical features.

---

## 10. Feature Engineering

1. **Floor Parsing**:
   - `Floor_Level`: Numerical floor height (Basement = -1/-2, Ground = 0, Upper Floors = integer).
   - `Total_Floors`: Total building elevation.
2. **Domain-Specific Ratios**:
   - `Size_per_BHK`: Spatial roominess ($Size / BHK$).
   - `Bathroom_to_BHK`: Luxury ratio ($Bathroom / BHK$).
   - `Rent_per_SqFt`: Target density ($Rent / Size$) for EDA analysis.
3. **Encoding & Standardization**:
   - Continuous numerical features scaled using `StandardScaler` (zero mean, unit variance).
   - Categorical features encoded with `OneHotEncoder(drop='first')`.

---

## 11. Machine Learning Algorithms

We evaluated four algorithms:

### 1. Linear Regression (Ordinary Least Squares)
Fits a hyperplane minimizing the sum of squared differences between observed and predicted targets:
$$\hat{y} = \beta_0 + \sum_{j=1}^p \beta_j x_j$$
- **Strengths**: Highly interpretable, fast training, optimal under strict linearity.
- **Weaknesses**: Cannot capture non-linear regional interactions or threshold jumps without manual interaction terms.

### 2. Decision Tree Regressor (CART)
Recursively partitions feature space into orthogonal hyper-rectangles by maximizing variance reduction:
$$\Delta I = \text{Var}(D) - \left( \frac{|D_L|}{|D|}\text{Var}(D_L) + \frac{|D_R|}{|D|}\text{Var}(D_R) \right)$$
- **Strengths**: Captures non-linear relationships, intuitive decision logic.
- **Weaknesses**: Prone to high variance and overfitting on localized training quirks.

### 3. Random Forest Regressor (Ensemble Bagging)
Constructs an ensemble of $B$ decorrelated decision trees using bootstrap sampling and random feature subspace projection:
$$\hat{f}_{\text{RF}}(\mathbf{x}) = \frac{1}{B} \sum_{b=1}^B T_b(\mathbf{x})$$
- **Strengths**: Dramatically reduces prediction variance, robust against outliers, captures complex multi-variable interactions.
- **Weaknesses**: Higher computational footprint than linear models.

### 4. Gradient Boosting Regressor (Sequential Boosting)
Sequentially fits decision trees to the negative gradient (pseudo-residuals) of the loss function:
$$f_m(\mathbf{x}) = f_{m-1}(\mathbf{x}) + \eta \cdot h_m(\mathbf{x})$$
- **Strengths**: Often achieves the lowest absolute errors by focusing on difficult-to-predict residual samples.
- **Weaknesses**: Requires tuning of learning rate $\eta$ and tree depth to avoid overfitting.

---

## 12. Model Training & Leakage Prevention

The dataset was partitioned into:
- **80% Training Split**: 3,792 records
- **20% Testing Split**: 949 records
- Seed: `random_state=42`

### Pipeline Architecture:
```text
Raw Features (X) ──> ColumnTransformer ──> Estimator ──> Log-Scale Forecast (ŷ_log) ──> exp(ŷ) - 1 ──> Rent (INR)
                     ├── SimpleImputer(median) + StandardScaler (Numeric)
                     └── SimpleImputer(mode)   + OneHotEncoder(drop='first') (Categorical)
```
The `ColumnTransformer` is fitted **strictly on `X_train`** and only transforms `X_test`, preventing data leakage.

---

## 13. Model Prediction System

The system provides interactive, validated predictions:
- **Inputs**: City (dropdown), BHK (numeric), Size in sq.ft. (numeric), Bathrooms (numeric), Floor Level (numeric), Total Floors (numeric), Area Type (dropdown), Furnishing Status (dropdown), Tenant Preference (dropdown), Point of Contact (dropdown), Locality (text).
- **Validation**: Enforces $Size > 0$, $BHK \ge 1$, $Bathrooms \ge 1$, $Floor\_Level \le Total\_Floors$.
- **Inference**: Loads `models/best_house_rent_model.pkl` with zero retraining.
- **Output Format**: Displays formatted rent in Indian Rupees (e.g. `Predicted Monthly House Rent: ₹19,125`), selected model name, and realistic estimation disclaimers.

---

## 14. Performance Evaluation Metrics

- **Coefficient of Determination ($R^2$ Score)**:
  $$R^2 = 1 - \frac{\sum_{i=1}^n (y_i - \hat{y}_i)^2}{\sum_{i=1}^n (y_i - \bar{y})^2}$$
- **Mean Absolute Error (MAE)**:
  $$\text{MAE} = \frac{1}{n} \sum_{i=1}^n |y_i - \hat{y}_i|$$
- **Mean Squared Error (MSE)**:
  $$\text{MSE} = \frac{1}{n} \sum_{i=1}^n (y_i - \hat{y}_i)^2$$
- **Root Mean Squared Error (RMSE)**:
  $$\text{RMSE} = \sqrt{\frac{1}{n} \sum_{i=1}^n (y_i - \hat{y}_i)^2}$$

---

## 15. Model Comparison & Benchmark Results

### Official Comparison Table (Evaluated on Unseen 20% Test Split)
Saved as [outputs/model_comparison.csv](file:///c:/Users/Asus/Documents/Desktop/house_prediction/outputs/model_comparison.csv):

| Model Name | R² Score | MAE | MSE | RMSE |
| :--- | :---: | :---: | :---: | :---: |
| **Random Forest Regressor** | **0.7681** | **₹ 9,527.53** | **665,147,102.84** | **₹ 25,790.45** |
| **Gradient Boosting Regressor** | 0.7671 | ₹ 9,429.02 | 668,132,844.12 | ₹ 25,848.27 |
| **Linear Regression** | 0.7411 | ₹ 10,544.72 | 742,456,315.31 | ₹ 27,248.05 |
| **Decision Tree Regressor** | 0.7273 | ₹ 11,032.90 | 782,086,402.50 | ₹ 27,965.81 |

### Comparative Graphs Generated in `outputs/graphs/`:
- `model_r2_comparison.png`
- `model_mae_comparison.png`
- `model_rmse_comparison.png`
- `model_performance_comparison.png`

---

## 16. Results and Discussion

1. **Random Forest Superiority**: Achieved the highest $R^2$ score (**0.7681**) and lowest RMSE (**₹ 25,790.45**). Ensemble averaging over 150 decorrelated trees successfully reduced prediction variance on unseen properties.
2. **Gradient Boosting Precision**: Achieved the lowest Mean Absolute Error (**₹ 9,429.02**), showing high accuracy on typical market listings.
3. **Bias vs. Variance Trade-Off**:
   - Single Decision Tree overfit the training partition (Train $R^2 = 0.8452$ vs Test $R^2 = 0.7273$).
   - Random Forest stabilized test performance (Train $R^2 = 0.9119$ vs Test $R^2 = 0.7681$).
   - Linear Regression exhibited underfitting (Train $R^2 = 0.6935$), confirming that linear assumptions do not capture non-linear real estate pricing.
4. **Primary Market Drivers**: Gini feature importance confirmed that `Size` (sq.ft.), `City_Mumbai`, `Bathroom count`, and `BHK` contribute over 75% of model predictive weight.

---

## 17. Conclusion

This project developed a supervised machine learning regression system for predicting residential house rental prices across six major Indian metropolitan cities. 

Key Findings:
1. **Target Normalization**: Logarithmic transformation $\log(1 + y)$ normalized residual distributions and improved linear and tree model stability.
2. **Feature Engineering**: Deconstructing composite floor text into `Floor_Level` and `Total_Floors` alongside spatial ratios (`Size_per_BHK`) added predictive value without dimensional explosion.
3. **Ensemble Value**: Ensemble architectures (**Random Forest** and **Gradient Boosting**) outperformed parametric linear models on real estate valuation.
4. **Deployment**: Serialized pipeline into `models/best_house_rent_model.pkl` and delivered a web application in `app.py`.

---

## 18. Future Scope

1. **Geospatial POI Integration**: Incorporate latitude/longitude coordinates to calculate walking distances to metro stations, tech corridors, and schools.
2. **Deep Learning Entity Embeddings**: Train TabNet and Multi-Layer Perceptrons (MLPs) with learned categorical embeddings for micro-localities.
3. **Computer Vision for Quality Estimation**: Ingest property interior photographs using CNNs (e.g. ResNet) to quantify interior aesthetics and finishes.
4. **Cloud Microservice Deployment**: Containerize the Streamlit web dashboard with Docker and deploy to AWS/GCP with automated CI/CD pipelines.

---

## 19. References

1. Banerjee, S. (2022). *House Rent Prediction Dataset*. Kaggle.  
   https://www.kaggle.com/datasets/iamsouravbanerjee/house-rent-prediction-dataset
2. Breiman, L. (2001). *Random Forests*. Machine Learning, 45(1), 5-32.
3. Friedman, J. H. (2001). *Greedy Function Approximation: A Gradient Boosting Machine*. Annals of Statistics, 29(5), 1189-1232.
4. Pedregosa, F., et al. (2011). *Scikit-learn: Machine Learning in Python*. Journal of Machine Learning Research, 12, 2825-2830.
5. McKinney, W. (2010). *Data Structures for Statistical Computing in Python*. Proceedings of the 9th Python in Science Conference, 51-56.

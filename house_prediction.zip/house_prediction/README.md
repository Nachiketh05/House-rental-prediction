# House Rental Price Prediction Using Machine Learning

An end-to-end academic machine learning project predicting residential rental prices across major Indian metropolitan cities using the real **Kaggle Indian House Rent Prediction Dataset**.

---

## 📋 Table of Contents
- [Project Overview](#-project-overview)
- [Problem Statement](#-problem-statement)
- [Objectives](#-objectives)
- [Dataset Description](#-dataset-description)
- [Folder Structure](#-folder-structure)
- [System Architecture & Methodology](#-system-architecture--methodology)
- [Feature Engineering Highlights](#-feature-engineering-highlights)
- [Machine Learning Models & Benchmark Results](#-machine-learning-models--benchmark-results)
- [Key Insights from EDA](#-key-insights-from-eda)
- [Testing & Quality Verification (PROMPT 9)](#-testing--quality-verification-prompt-9)
- [Interactive Streamlit Dashboard (PROMPT 8)](#-interactive-streamlit-dashboard-prompt-8)
- [Academic Documentation & Presentation (PROMPT 10)](#-academic-documentation--presentation-prompt-10)
- [Installation and Setup](#-installation-and-setup)
- [How to Run the Project](#-how-to-run-the-project)
- [Generated Visualizations](#-generated-visualizations)
- [Conclusion & Future Scope](#-conclusion--future-scope)
- [Citation & References](#-citation--references)

---

## 🎯 Project Overview

In major Indian metropolitan areas (**Mumbai, Bangalore, Delhi, Hyderabad, Chennai, Kolkata**), finding fair-market residential rental rates is a challenge due to unregulated pricing, speculative listings, and fragmented brokerage networks. This project develops an end-to-end Machine Learning solution to accurately estimate rental prices in Indian Rupees (INR / ₹) based on structural property characteristics, demographic indicators, and regional attributes.

---

## 🔍 Problem Statement

Rental price determination in Indian urban markets is non-transparent and influenced by complex interactions between carpet area, bedroom configurations (BHK), floor level, furnishing quality, and regional location. Prospective tenants often overpay due to lack of market data, while property owners risk extended vacancies due to unrealistic pricing. 

This project formulates rent estimation as a **Supervised Regression Problem**:
$$\hat{y} = f(\mathbf{x})$$
where $\mathbf{x}$ encompasses property attributes and $\hat{y}$ represents the estimated monthly rent in INR.

---

## 🎯 Objectives

1. Ingest and validate the authentic Kaggle Indian House Rent Prediction Dataset (4,746 real property records).
2. Clean raw data, eliminate duplicates, audit outliers, and stabilize target variance using log-transformations.
3. Conduct in-depth **Exploratory Data Analysis (EDA)** and generate publication-quality visualizations.
4. Extract structured numerical signals from composite text (such as floor elevation strings) and compute domain-specific ratios.
5. Train and benchmark **six Machine Learning regression algorithms**:
   - Linear Regression (Ordinary Least Squares)
   - Ridge Regression ($L_2$ Regularization)
   - Lasso Regression ($L_1$ Regularization)
   - Decision Tree Regressor (CART)
   - Random Forest Regressor (Ensemble Bagging)
   - Gradient Boosting Regressor (Ensemble Boosting)
6. Evaluate model performance using standard academic metrics: **MAE**, **MSE**, **RMSE**, and **$R^2$ Score**.
7. Serialize the best model (`.pkl`) and deploy an interactive **Streamlit web dashboard** for instant real-time predictions.

---

## 📊 Dataset Description

- **Source**: [Kaggle - House Rent Prediction Dataset](https://www.kaggle.com/datasets/iamsouravbanerjee/house-rent-prediction-dataset)
- **Author**: Sourav Banerjee
- **Total Records**: 4,746 listings
- **Target Variable**: `Rent` (Monthly rental price in INR / ₹)

### Attribute Dictionary

| Attribute | Data Type | Description |
| :--- | :--- | :--- |
| `Posted On` | Date | Date the rental listing was published. |
| `BHK` | Integer | Number of Bedrooms, Hall, and Kitchen (1 to 6). |
| `Rent` | Integer | Target variable: Monthly rent in Indian Rupees (INR). |
| `Size` | Integer | Total property area measured in square feet (sq. ft.). |
| `Floor` | String | Floor elevation and building floors (e.g., `'1 out of 3'`, `'Ground out of 2'`). |
| `Area Type` | Categorical | Area measurement: *Super Area*, *Carpet Area*, or *Built Area*. |
| `Area Locality` | Categorical | Specific neighborhood or locality. |
| `City` | Categorical | Metropolitan city (*Kolkata, Mumbai, Bangalore, Delhi, Chennai, Hyderabad*). |
| `Furnishing Status`| Categorical | Property furnishing condition (*Unfurnished, Semi-Furnished, Furnished*). |
| `Tenant Preferred` | Categorical | Landlord tenant preference (*Bachelors/Family, Bachelors, Family*). |
| `Bathroom` | Integer | Total number of bathrooms (1 to 10). |
| `Point of Contact`| Categorical | Primary contact (*Contact Owner, Contact Agent, Contact Builder*). |

---

## 📁 Folder Structure

```text
House_Rental_Prediction/
│
├── dataset/
│   └── House_Rent_Dataset.csv          # Real Indian Kaggle dataset (4,746 rows)
│
├── notebooks/
│   └── House_Rent_Prediction.ipynb     # Complete 12-section Academic Jupyter Notebook
│
├── models/
│   ├── best_house_rent_model.pkl       # Serialized best ML pipeline (Random Forest)
│   └── preprocessor.pkl                # Serialized ColumnTransformer
│
├── outputs/
│   ├── graphs/                         # High-resolution saved visualization figures
│   │   ├── rent_distribution.png
│   │   ├── city_wise_rent_boxplot.png
│   │   ├── rent_vs_size_scatter.png
│   │   ├── bhk_and_furnishing_rent.png
│   │   ├── correlation_heatmap.png
│   │   ├── actual_vs_predicted.png
│   │   ├── residuals_distribution.png
│   │   └── feature_importance.png
│   └── model_comparison.csv            # Benchmarking metrics across all algorithms
│
├── app.py                              # Interactive Streamlit Web Application
├── requirements.txt                    # Project dependencies
├── README.md                           # Comprehensive academic documentation
├── generate_notebook.py                # Standalone notebook generator utility
└── main.py                             # Complete end-to-end Python pipeline
```

---

## ⚙️ System Architecture & Methodology

```mermaid
flowchart TD
    A["Raw Dataset (Kaggle CSV)"] --> B["Data Preprocessing & Cleaning"]
    B --> C["Outlier Audit & Log Target Transform"]
    B --> D["Feature Engineering (Floor Parsing, Ratios)"]
    D --> E["ColumnTransformer Pipeline"]
    E --> F["Train/Test Split (80% / 20%)"]
    F --> G["Model Training (6 Algorithms)"]
    G --> H["Model Evaluation (MAE, RMSE, R2)"]
    H --> I["Best Model Export (models/best_house_rent_model.pkl)"]
    I --> J["Streamlit Interactive Web Dashboard (app.py)"]
```

---

## 🛠️ Feature Engineering Highlights

1. **Floor String Deconstruction**:
   - Converts unstructured strings like `'Ground out of 2'` or `'14 out of 25'` into:
     - `Floor_Level`: Numerical level (Ground = 0, Basement = -1 / -2, or floor number).
     - `Total_Floors`: Total building elevation floors.
2. **Real Estate Domain Ratios**:
   - `Size_per_BHK`: Total square footage divided by BHK count.
   - `Bathroom_to_BHK`: Bathroom-to-bedroom proportionality.
3. **Target Normalization**:
   - Due to extreme right-skewness, the target variable is transformed using $y_{\text{train}} = \log(1 + \text{Rent})$.
   - Forecasts are mapped back to real rupees using $\hat{y}_{\text{INR}} = \exp(\hat{y}_{\text{log}}) - 1$.
4. **Encoding & Standardization**:
   - `OneHotEncoder(drop='first')` for nominal categorical variables (`City`, `Furnishing Status`, `Tenant Preferred`, etc.).
   - `StandardScaler()` for continuous numerical variables.

---

## 🏆 Machine Learning Models & Benchmark Results

All models were evaluated on the **same 20% unseen test split (949 listings)**:

| Model Architecture | MAE (INR) | RMSE (INR) | $R^2$ Score (INR) | $R^2$ (Log Scale) |
| :--- | :---: | :---: | :---: | :---: |
| **Random Forest Regressor** | **₹ 9,527.53** | **₹ 25,790.45** | **0.7681** | **0.8168** |
| **Gradient Boosting Regressor** | ₹ 9,429.02 | ₹ 25,848.27 | 0.7671 | 0.8229 |
| **Linear Regression (OLS)** | ₹ 10,544.72 | ₹ 27,248.05 | 0.7411 | 0.8087 |
| **Ridge Regression ($L_2$)** | ₹ 10,548.77 | ₹ 27,263.12 | 0.7409 | 0.8088 |
| **Lasso Regression ($L_1$)** | ₹ 10,540.75 | ₹ 27,290.97 | 0.7403 | 0.8083 |
| **Decision Tree Regressor** | ₹ 11,441.38 | ₹ 28,147.04 | 0.7238 | 0.7708 |

### Key Observations:
- **Random Forest** achieved the highest overall $R^2$ score (**0.7681** on original scale, **0.8168** on log scale) and lowest prediction dispersion.
- **Gradient Boosting** achieved the lowest Mean Absolute Error (**₹ 9,429.02**).
- Ensemble non-linear tree models outperformed linear models because housing rent exhibits localized, non-linear pricing jumps across cities.

---

## 💡 Key Insights from EDA

1. **City Premium**: Mumbai commands significantly higher median rents (median ₹ 38,000) compared to Delhi (₹ 16,000), Bangalore (₹ 13,500), and Kolkata (₹ 9,000).
2. **Furnishing Impact**: Fully furnished homes command a 40%–55% rental premium over unfurnished units across identical BHK configurations.
3. **Floor Premium**: In high-rise metropolitan buildings, higher floor elevations correlate positively with higher rental values.
4. **Primary Drivers**: Feature importance analysis shows that `Size`, `City_Mumbai`, `Bathroom count`, and `BHK` account for over 75% of model predictive weight.

---

## 🧪 Testing & Quality Verification (PROMPT 9)

Every module, pipeline stage, and asset has undergone automated validation:
1. **Dataset Integrity**: Ingested `dataset/House_Rent_Dataset.csv` (4,746 rows, 12 features) with zero missing entries and zero duplicates.
2. **Preprocessing & Pre-Leakage Audit**: `ColumnTransformer` fitted strictly on `X_train`. Target variable `Rent` completely isolated.
3. **Model Convergence & Training**: All 4 models trained under `random_state=42` on the exact same train/test splits.
4. **Metric Verification**: Calculated exact $R^2$, MAE, MSE, and RMSE without hardcoded or synthetic values.
5. **Model Persistence & Reload**: Serialized `models/best_house_rent_model.pkl` with Joblib and validated reload inference.
6. **Notebook Execution**: Executed all 46 code cells in `notebooks/House_Rent_Prediction.ipynb` sequentially from first to last without errors.
7. **Streamlit Application**: Verified live interactive execution across all 6 modules.

---

## 💻 Interactive Streamlit Dashboard (PROMPT 8)

The application in `app.py` is titled **HOUSE RENTAL PRICE PREDICTION SYSTEM** and includes 6 navigation views:
1. **Home**: Project introduction, system architecture, KPI cards.
2. **Dataset Overview**: Attribute definitions, data sample, and cleaning audit.
3. **EDA and Visualizations**: Visual displays of all 12 EDA figures with detailed observation notes.
4. **Model Comparison**: Metric comparison table and comparative evaluation charts ($R^2$, MAE, RMSE).
5. **Rent Prediction**: Interactive input form (City, BHK, Size, Bathrooms, Floor, Furnishing, etc.), input validation, model disclosure, and realistic estimated price disclaimers.
6. **About Project**: Academic capstone details, methodology, conclusion, and future scope.

---

## 📚 Academic Documentation & Presentation (PROMPT 10)

For comprehensive college machine learning project presentations and viva defense:
- See the complete 19-section academic thesis report: [ACADEMIC_PROJECT_REPORT.md](ACADEMIC_PROJECT_REPORT.md).
- Covers theoretical formulations, algorithmic mechanics, bias-variance analysis, real computed benchmark figures, and academic citations.

---

## 💻 Installation and Setup

### Prerequisites
- Python 3.9, 3.10, 3.11, or 3.12
- `pip` package manager

### 1. Clone or Open Workspace
```bash
cd house_prediction
```

### 2. Create and Activate Virtual Environment (Optional but recommended)
```bash
# Windows
python -m venv venv
venv\Scripts\activate

# Linux / macOS
python3 -m venv venv
source venv/bin/activate
```

### 3. Install Dependencies
```bash
pip install -r requirements.txt
```

---

## 🚀 How to Run the Project

### 1. Running the Automated Pipeline (main.py)
To execute the complete end-to-end data pipeline, train all 6 algorithms, generate all graphs, and save the best model:

```bash
python main.py
```

### 2. Running the Academic Jupyter Notebook
To interactively view and run each of the 12 academic sections with markdown notes and code cells:

```bash
jupyter notebook notebooks/House_Rent_Prediction.ipynb
```
*(Or open `notebooks/House_Rent_Prediction.ipynb` directly in VS Code / JupyterLab / Google Colab).*

### 3. Running the Interactive Streamlit Web App
To launch the user-friendly web application for real-time rent predictions:

```bash
streamlit run app.py
```
This opens the browser dashboard at `http://localhost:8501`.

---

## 📈 Generated Visualizations

All graphs are automatically generated and saved to `outputs/graphs/`:
- `rent_distribution.png`: Raw vs. Log-transformed target distribution.
- `city_wise_rent_boxplot.png`: City-by-city rental variations.
- `rent_vs_size_scatter.png`: Size vs. Rent across regional markets.
- `bhk_and_furnishing_rent.png`: Rental uplifts across BHK configurations and furnishings.
- `correlation_heatmap.png`: Pearson correlation matrix of engineered features.
- `actual_vs_predicted.png`: Best model test predictions vs. ground truth.
- `residuals_distribution.png`: Histogram of model prediction residuals.
- `feature_importance.png`: Top 12 predictive features from Random Forest.

---

## 🎓 Conclusion & Future Scope

### Academic Conclusion
The project demonstrates that ensemble tree architectures (Random Forest and Gradient Boosting) paired with logarithmic target transformation provide high accuracy ($R^2 \approx 0.77$, MAE $\approx ₹ 9,500$) for predicting Indian rental prices, balancing interpretability and generalization.

### Future Scope
1. **Geospatial Proximity**: Integrating GPS coordinates to calculate walking distance to tech parks, metro stations, and schools.
2. **Deep Learning**: Training TabNet and Multi-Layer Perceptrons with learned entity embeddings for locality names.
3. **Computer Vision**: Analyzing property interior photographs using CNNs to assess luxury finishes.
4. **Cloud API**: Containerizing the model using Docker and deploying as a REST API on AWS/GCP.

---

## 📚 Citation & References

1. Banerjee, Sourav. (2022). *House Rent Prediction Dataset*. Kaggle.  
   https://www.kaggle.com/datasets/iamsouravbanerjee/house-rent-prediction-dataset
2. Scikit-learn: Machine Learning in Python, Pedregosa et al., JMLR 12, pp. 2825-2830, 2011.
3. McKinney, Wes. *Data Structures for Statistical Computing in Python*, Proceedings of the 9th Python in Science Conference, 2010.

"""
House Rental Price Prediction Using Machine Learning
Academic ML Project - Main Execution Pipeline

Fully compliant with PROMPT 1 through PROMPT 7.
"""

import os
import sys
import warnings
import tempfile

os.environ['MPLCONFIGDIR'] = os.path.join(tempfile.gettempdir(), 'mpl_cache')
warnings.filterwarnings('ignore')

import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import seaborn as sns
import joblib

from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler, OneHotEncoder
from sklearn.impute import SimpleImputer
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.linear_model import LinearRegression
from sklearn.tree import DecisionTreeRegressor
from sklearn.ensemble import RandomForestRegressor, GradientBoostingRegressor
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score


def parse_floor(val):
    val = str(val).strip()
    if 'out of' in val:
        parts = val.split('out of')
        curr_str = parts[0].strip()
        total_str = parts[1].strip()
    else:
        curr_str = val
        total_str = val

    if 'Ground' in curr_str:
        floor_level = 0
    elif 'Upper Basement' in curr_str:
        floor_level = -1
    elif 'Lower Basement' in curr_str:
        floor_level = -2
    else:
        try:
            floor_level = int(curr_str)
        except ValueError:
            floor_level = 0

    if 'Ground' in total_str:
        total_floors = 1
    else:
        try:
            total_floors = int(total_str)
        except ValueError:
            total_floors = max(1, floor_level if floor_level > 0 else 1)

    return floor_level, total_floors


def load_and_preprocess(dataset_path="dataset/House_Rent_Dataset.csv"):
    if not os.path.exists(dataset_path):
        raise FileNotFoundError(f"Dataset not found at {dataset_path}")

    print("[1/5] Loading and Auditing Dataset...")
    df = pd.read_csv(dataset_path)
    print(f"      Initial Shape: {df.shape[0]} rows x {df.shape[1]} columns")

    # Audit Missing Values
    missing = df.isnull().sum().sum()
    print(f"      Missing Values Detected: {missing}")

    # Audit Duplicates
    duplicates = df.duplicated().sum()
    print(f"      Duplicate Records: {duplicates}")
    if duplicates > 0:
        df = df.drop_duplicates().reset_index(drop=True)

    # Clean String Columns
    str_cols = df.select_dtypes(include=['object', 'string']).columns.tolist()
    for c in str_cols:
        df[c] = df[c].astype(str).str.strip()

    # Sanity Checks on Numeric Columns
    invalid_size = (df['Size'] <= 0).sum()
    invalid_rent = (df['Rent'] <= 0).sum()
    print(f"      Invalid Values Check (Size <= 0: {invalid_size}, Rent <= 0: {invalid_rent})")

    # Feature Engineering
    floor_res = df['Floor'].apply(parse_floor)
    df['Floor_Level'] = [r[0] for r in floor_res]
    df['Total_Floors'] = [r[1] for r in floor_res]
    df['Size_per_BHK'] = df['Size'] / df['BHK']
    df['Bathroom_to_BHK'] = df['Bathroom'] / df['BHK']
    df['Rent_per_SqFt'] = df['Rent'] / df['Size']
    df['Posted_Date'] = pd.to_datetime(df['Posted On'], errors='coerce')
    df['Posting_Month'] = df['Posted_Date'].dt.month

    # Outlier Handling (> 99.9th percentile)
    q_high = df['Rent'].quantile(0.999)
    outliers_count = (df['Rent'] > q_high).sum()
    print(f"      Trimming {outliers_count} extreme anomaly listings above INR {q_high:,.0f} (e.g. Marathahalli error)...")
    df_clean = df[df['Rent'] <= q_high].copy().reset_index(drop=True)
    print(f"      Cleaned Shape: {df_clean.shape[0]} rows x {df_clean.shape[1]} columns")

    return df_clean


def generate_all_visualizations(df, output_dir="outputs/graphs"):
    os.makedirs(output_dir, exist_ok=True)
    print(f"[2/5] Generating all required academic visualization plots in '{output_dir}'...")

    sns.set_theme(style="whitegrid", palette="deep")
    plt.rcParams.update({'font.sans-serif': 'DejaVu Sans', 'font.size': 11})

    # 1. Bar chart – Average rent by city
    plt.figure(figsize=(10, 6))
    avg_city_rent = df.groupby('City')['Rent'].mean().sort_values(ascending=False)
    ax1 = sns.barplot(x=avg_city_rent.index, y=avg_city_rent.values, palette='Blues_r')
    plt.title('Figure 1: Average Monthly Rent Across Indian Metropolitan Cities', fontsize=13, fontweight='bold', pad=15)
    plt.xlabel('Metropolitan City', fontsize=11)
    plt.ylabel('Average Monthly Rent (INR / ₹)', fontsize=11)
    plt.ylim(0, avg_city_rent.max() * 1.15)
    for p in ax1.patches:
        h = p.get_height()
        ax1.annotate(f'INR {h:,.0f}', (p.get_x() + p.get_width() / 2., h),
                     ha='center', va='bottom', fontsize=10, fontweight='bold', xytext=(0, 4), textcoords='offset points')
    plt.tight_layout()
    plt.savefig(os.path.join(output_dir, "bar_average_rent_by_city.png"), dpi=300)
    plt.close()

    # 2. Bar chart – Number of houses in each city
    plt.figure(figsize=(10, 6))
    city_counts = df['City'].value_counts()
    ax2 = sns.barplot(x=city_counts.index, y=city_counts.values, palette='crest')
    plt.title('Figure 2: Total Number of Rental Listings Available in Each City', fontsize=13, fontweight='bold', pad=15)
    plt.xlabel('Metropolitan City', fontsize=11)
    plt.ylabel('Listing Count (Number of Houses)', fontsize=11)
    plt.ylim(0, city_counts.max() * 1.12)
    for p in ax2.patches:
        val = int(p.get_height())
        ax2.annotate(f'{val:,} units', (p.get_x() + p.get_width() / 2., val),
                     ha='center', va='bottom', fontsize=10, fontweight='bold', xytext=(0, 4), textcoords='offset points')
    plt.tight_layout()
    plt.savefig(os.path.join(output_dir, "bar_houses_count_by_city.png"), dpi=300)
    plt.close()

    # 3. Bar chart – Average rent by BHK
    plt.figure(figsize=(10, 6))
    avg_bhk = df.groupby('BHK')['Rent'].mean()
    ax3 = sns.barplot(x=avg_bhk.index, y=avg_bhk.values, palette='viridis')
    plt.title('Figure 3: Average Monthly Rent by BHK Configuration', fontsize=13, fontweight='bold', pad=15)
    plt.xlabel('BHK (Bedrooms, Hall, Kitchen)', fontsize=11)
    plt.ylabel('Average Monthly Rent (INR / ₹)', fontsize=11)
    plt.ylim(0, avg_bhk.max() * 1.15)
    for p in ax3.patches:
        h = p.get_height()
        ax3.annotate(f'INR {h:,.0f}', (p.get_x() + p.get_width() / 2., h),
                     ha='center', va='bottom', fontsize=10, fontweight='bold', xytext=(0, 4), textcoords='offset points')
    plt.tight_layout()
    plt.savefig(os.path.join(output_dir, "bar_average_rent_by_bhk.png"), dpi=300)
    plt.close()

    # 4. Bar chart – Average rent by furnishing status
    plt.figure(figsize=(9, 6))
    avg_furn = df.groupby('Furnishing Status')['Rent'].mean().sort_values(ascending=False)
    ax4 = sns.barplot(x=avg_furn.index, y=avg_furn.values, palette='magma')
    plt.title('Figure 4: Average Monthly Rent by Furnishing Status', fontsize=13, fontweight='bold', pad=15)
    plt.xlabel('Furnishing Status', fontsize=11)
    plt.ylabel('Average Monthly Rent (INR / ₹)', fontsize=11)
    plt.ylim(0, avg_furn.max() * 1.15)
    for p in ax4.patches:
        h = p.get_height()
        ax4.annotate(f'INR {h:,.0f}', (p.get_x() + p.get_width() / 2., h),
                     ha='center', va='bottom', fontsize=10, fontweight='bold', xytext=(0, 4), textcoords='offset points')
    plt.tight_layout()
    plt.savefig(os.path.join(output_dir, "bar_average_rent_by_furnishing.png"), dpi=300)
    plt.close()

    # 5. Histogram – Distribution of rental prices
    fig, axes = plt.subplots(1, 2, figsize=(15, 6))
    sns.histplot(df['Rent'], kde=True, ax=axes[0], color='#2980b9', bins=50)
    axes[0].set_title('Raw Monthly Rent (Extreme Right Skewness)', fontsize=13, fontweight='bold')
    axes[0].set_xlabel('Monthly Rent (INR / ₹)', fontsize=11)
    axes[0].set_ylabel('Listing Frequency', fontsize=11)
    sns.histplot(np.log1p(df['Rent']), kde=True, ax=axes[1], color='#27ae60', bins=40)
    axes[1].set_title('Log-Transformed Rent [log(Rent + 1)] (Normalized Bell Curve)', fontsize=13, fontweight='bold')
    axes[1].set_xlabel('log(Rent + 1)', fontsize=11)
    axes[1].set_ylabel('Listing Frequency', fontsize=11)
    plt.tight_layout()
    plt.savefig(os.path.join(output_dir, "histogram_rent_distribution.png"), dpi=300)
    plt.savefig(os.path.join(output_dir, "rent_distribution.png"), dpi=300)
    plt.close()

    # 6. Scatter plot – House size versus rental price
    plt.figure(figsize=(11, 6))
    sns.scatterplot(x='Size', y='Rent', hue='City', data=df[df['Rent'] <= 250000], alpha=0.65, palette='tab10', s=50)
    plt.title('Figure 6: Property Size (Square Feet) vs. Monthly Rent (INR)', fontsize=13, fontweight='bold', pad=15)
    plt.xlabel('Property Size (Square Feet)', fontsize=11)
    plt.ylabel('Monthly Rent (INR / ₹)', fontsize=11)
    plt.legend(title='City', bbox_to_anchor=(1.02, 1), loc='upper left')
    plt.tight_layout()
    plt.savefig(os.path.join(output_dir, "scatter_size_vs_rent.png"), dpi=300)
    plt.savefig(os.path.join(output_dir, "rent_vs_size_scatter.png"), dpi=300)
    plt.close()

    # 7. Box plot – Rent distribution across cities
    plt.figure(figsize=(11, 6))
    order_cities = df.groupby('City')['Rent'].median().sort_values(ascending=False).index
    sns.boxplot(x='City', y='Rent', data=df, order=order_cities, palette='Set2', showfliers=False)
    plt.title('Figure 7: Monthly Rent Distribution Across Cities (Excluding Fliers)', fontsize=13, fontweight='bold', pad=15)
    plt.xlabel('Metropolitan City', fontsize=11)
    plt.ylabel('Monthly Rent (INR / ₹)', fontsize=11)
    plt.tight_layout()
    plt.savefig(os.path.join(output_dir, "boxplot_rent_by_city.png"), dpi=300)
    plt.savefig(os.path.join(output_dir, "city_wise_rent_boxplot.png"), dpi=300)
    plt.close()

    # 8. Box plot – Rent based on furnishing status
    plt.figure(figsize=(10, 6))
    order_furn = ['Furnished', 'Semi-Furnished', 'Unfurnished']
    sns.boxplot(x='Furnishing Status', y='Rent', data=df, order=order_furn, palette='Pastel1', showfliers=False)
    plt.title('Figure 8: Monthly Rent Distribution by Furnishing Status', fontsize=13, fontweight='bold', pad=15)
    plt.xlabel('Furnishing Status', fontsize=11)
    plt.ylabel('Monthly Rent (INR / ₹)', fontsize=11)
    plt.tight_layout()
    plt.savefig(os.path.join(output_dir, "boxplot_rent_by_furnishing.png"), dpi=300)
    plt.close()

    # 9. Heatmap – Correlation between numerical features
    plt.figure(figsize=(10, 8))
    numeric_cols = ['Rent', 'BHK', 'Size', 'Bathroom', 'Floor_Level', 'Total_Floors', 'Size_per_BHK', 'Bathroom_to_BHK']
    corr_data = df[numeric_cols].corr()
    mask = np.triu(np.ones_like(corr_data, dtype=bool))
    sns.heatmap(corr_data, annot=True, fmt=".2f", cmap='Blues', mask=mask, cbar_kws={'label': 'Pearson Correlation (r)'}, vmin=-0.2, vmax=1.0)
    plt.title('Figure 9: Pearson Correlation Matrix of Quantitative Features', fontsize=13, fontweight='bold', pad=15)
    plt.tight_layout()
    plt.savefig(os.path.join(output_dir, "heatmap_numerical_correlation.png"), dpi=300)
    plt.savefig(os.path.join(output_dir, "correlation_heatmap.png"), dpi=300)
    plt.close()

    # 10. Count plot – Distribution of BHK
    plt.figure(figsize=(10, 6))
    ax10 = sns.countplot(x='BHK', data=df, palette='Blues_d')
    plt.title('Figure 10: Listing Distribution Across BHK Configurations', fontsize=13, fontweight='bold', pad=15)
    plt.xlabel('BHK (Bedrooms, Hall, Kitchen)', fontsize=11)
    plt.ylabel('Total Number of Listings', fontsize=11)
    plt.ylim(0, df['BHK'].value_counts().max() * 1.15)
    for p in ax10.patches:
        val = int(p.get_height())
        pct = (val / len(df)) * 100
        ax10.annotate(f'{val:,}\\n({pct:.1f}%)', (p.get_x() + p.get_width() / 2., val),
                      ha='center', va='bottom', fontsize=10, fontweight='bold', xytext=(0, 4), textcoords='offset points')
    plt.tight_layout()
    plt.savefig(os.path.join(output_dir, "countplot_bhk_distribution.png"), dpi=300)
    plt.close()

    # 11. Bar chart – Average rent based on bathrooms
    plt.figure(figsize=(10, 6))
    avg_bath = df.groupby('Bathroom')['Rent'].mean()
    ax11 = sns.barplot(x=avg_bath.index, y=avg_bath.values, palette='coolwarm')
    plt.title('Figure 11: Average Monthly Rent Based on Number of Bathrooms', fontsize=13, fontweight='bold', pad=15)
    plt.xlabel('Number of Bathrooms', fontsize=11)
    plt.ylabel('Average Monthly Rent (INR / ₹)', fontsize=11)
    plt.ylim(0, avg_bath.max() * 1.15)
    for p in ax11.patches:
        h = p.get_height()
        ax11.annotate(f'INR {h:,.0f}', (p.get_x() + p.get_width() / 2., h),
                      ha='center', va='bottom', fontsize=10, fontweight='bold', xytext=(0, 4), textcoords='offset points')
    plt.tight_layout()
    plt.savefig(os.path.join(output_dir, "bar_average_rent_by_bathrooms.png"), dpi=300)
    plt.close()

    # 12. Pair plot – Important numerical features
    pairplot_cols = ['Rent', 'Size', 'BHK', 'Bathroom']
    pairplot_data = df[pairplot_cols].copy()
    pairplot_data['Rent_Log'] = np.log1p(pairplot_data['Rent'])
    g = sns.pairplot(
        pairplot_data[['Rent_Log', 'Size', 'BHK', 'Bathroom']],
        diag_kind='kde',
        plot_kws={'alpha': 0.4, 'color': '#2b5c8f'},
        diag_kws={'color': '#27ae60', 'fill': True}
    )
    g.fig.suptitle('Figure 12: Pairwise Bivariate Relationships Across Core Numerical Features', fontsize=13, fontweight='bold', y=1.02)
    g.savefig(os.path.join(output_dir, "pairplot_numerical_features.png"), dpi=300)
    plt.close()

    print(f"      Saved EDA plots to {output_dir}/")


def train_and_benchmark(df, outputs_dir="outputs", models_dir="models"):
    os.makedirs(outputs_dir, exist_ok=True)
    os.makedirs(models_dir, exist_ok=True)
    print("[3/5] Building Leakage-Free Scikit-Learn Pipelines & Training Models...")

    num_cols = ['BHK', 'Size', 'Bathroom', 'Floor_Level', 'Total_Floors', 'Size_per_BHK', 'Bathroom_to_BHK']
    cat_cols = ['City', 'Furnishing Status', 'Tenant Preferred', 'Area Type', 'Point of Contact']

    X = df[num_cols + cat_cols]
    y = np.log1p(df['Rent'])  # Target strictly excluded from X

    # 80% Train, 20% Test split (random_state=42)
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.20, random_state=42)

    # Scikit-learn Preprocessing Pipeline
    num_pipe = Pipeline([
        ('imputer', SimpleImputer(strategy='median')),
        ('scaler', StandardScaler())
    ])
    cat_pipe = Pipeline([
        ('imputer', SimpleImputer(strategy='most_frequent')),
        ('encoder', OneHotEncoder(drop='first', handle_unknown='ignore', sparse_output=False))
    ])

    preprocessor = ColumnTransformer(transformers=[
        ('num', num_pipe, num_cols),
        ('cat', cat_pipe, cat_cols)
    ])

    models = {
        'Linear Regression': LinearRegression(),
        'Decision Tree Regressor': DecisionTreeRegressor(max_depth=10, min_samples_leaf=4, random_state=42),
        'Random Forest Regressor': RandomForestRegressor(n_estimators=150, max_depth=15, min_samples_split=4, random_state=42, n_jobs=-1),
        'Gradient Boosting Regressor': GradientBoostingRegressor(n_estimators=150, learning_rate=0.08, max_depth=5, random_state=42)
    }

    train_actual = np.expm1(y_train)
    test_actual = np.expm1(y_test)
    records = []
    fitted_pipelines = {}

    print("\n" + "="*95)
    print(f"{'Model Name':<28} | {'Train R2':<10} | {'Test R2':<10} | {'Train MAE (INR)':<16} | {'Test MAE (INR)':<16}")
    print("="*95)

    for name, model in models.items():
        pipe = Pipeline([
            ('preprocessor', preprocessor),
            ('regressor', model)
        ])
        # Strict training fit to avoid data leakage
        pipe.fit(X_train, y_train)
        fitted_pipelines[name] = pipe

        train_pred_log = pipe.predict(X_train)
        train_pred_inr = np.expm1(train_pred_log)
        train_r2 = r2_score(train_actual, train_pred_inr)
        train_mae = mean_absolute_error(train_actual, train_pred_inr)

        pred_log = pipe.predict(X_test)
        pred_inr = np.expm1(pred_log)

        r2 = r2_score(test_actual, pred_inr)
        mae = mean_absolute_error(test_actual, pred_inr)
        mse = mean_squared_error(test_actual, pred_inr)
        rmse = np.sqrt(mse)

        records.append({
            'Model Name': name,
            'R² Score': round(r2, 4),
            'MAE': round(mae, 2),
            'MSE': round(mse, 2),
            'RMSE': round(rmse, 2)
        })
        print(f"{name:<28} | {train_r2:>10.4f} | {r2:>10.4f} | {train_mae:>16,.2f} | {mae:>16,.2f}")

    print("="*95)

    # DataFrame with required exact column names: Model Name | R² Score | MAE | MSE | RMSE
    comp_df = pd.DataFrame(records).sort_values(by='R² Score', ascending=False).reset_index(drop=True)
    comp_path = os.path.join(outputs_dir, "model_comparison.csv")
    comp_df.to_csv(comp_path, index=False, encoding='utf-8')
    print(f"[4/5] Saved model comparison metrics to: {comp_path}")
    print("\nModel Comparison Table:")
    print(comp_df.to_string(index=False))

    best_name = comp_df.iloc[0]['Model Name']
    best_pipe = fitted_pipelines[best_name]
    joblib.dump(best_pipe, os.path.join(models_dir, "best_house_rent_model.pkl"))
    print(f"\n      Exported best model ({best_name}) to {models_dir}/best_house_rent_model.pkl")

    # Generate Model Performance Comparison Charts
    graphs_dir = os.path.join(outputs_dir, "graphs")

    # 1. Bar chart comparing R² scores of all models
    plt.figure(figsize=(9, 5))
    ax = sns.barplot(x='R² Score', y='Model Name', data=comp_df, palette='Blues_r')
    plt.title('Model Benchmark: R² Score Comparison (Higher is Better)', fontsize=13, fontweight='bold', pad=15)
    plt.xlabel('R² Score', fontsize=11)
    plt.ylabel('Model Name', fontsize=11)
    plt.xlim(0, 1.0)
    for p in ax.patches:
        w = p.get_width()
        ax.annotate(f'{w:.4f}', (w + 0.02, p.get_y() + p.get_height() / 2.), ha='left', va='center', fontsize=10, fontweight='bold')
    plt.tight_layout()
    plt.savefig(os.path.join(graphs_dir, "model_r2_comparison.png"), dpi=300)
    plt.close()

    # 2. Bar chart comparing MAE of all models
    plt.figure(figsize=(9, 5))
    ax = sns.barplot(x='MAE', y='Model Name', data=comp_df.sort_values(by='MAE'), palette='Oranges_r')
    plt.title('Model Benchmark: Mean Absolute Error (MAE) Comparison (Lower is Better)', fontsize=13, fontweight='bold', pad=15)
    plt.xlabel('Mean Absolute Error (INR / ₹)', fontsize=11)
    plt.ylabel('Model Name', fontsize=11)
    for p in ax.patches:
        w = p.get_width()
        ax.annotate(f'INR {w:,.0f}', (w + 150, p.get_y() + p.get_height() / 2.), ha='left', va='center', fontsize=10, fontweight='bold')
    plt.tight_layout()
    plt.savefig(os.path.join(graphs_dir, "model_mae_comparison.png"), dpi=300)
    plt.close()

    # 3. Bar chart comparing RMSE of all models
    plt.figure(figsize=(9, 5))
    ax = sns.barplot(x='RMSE', y='Model Name', data=comp_df.sort_values(by='RMSE'), palette='Reds_r')
    plt.title('Model Benchmark: Root Mean Squared Error (RMSE) Comparison (Lower is Better)', fontsize=13, fontweight='bold', pad=15)
    plt.xlabel('Root Mean Squared Error (INR / ₹)', fontsize=11)
    plt.ylabel('Model Name', fontsize=11)
    for p in ax.patches:
        w = p.get_width()
        ax.annotate(f'INR {w:,.0f}', (w + 250, p.get_y() + p.get_height() / 2.), ha='left', va='center', fontsize=10, fontweight='bold')
    plt.tight_layout()
    plt.savefig(os.path.join(graphs_dir, "model_rmse_comparison.png"), dpi=300)
    plt.close()

    # 4. Model performance comparison chart (Side-by-side subplots)
    fig, axes = plt.subplots(1, 3, figsize=(18, 5))
    sns.barplot(x='R² Score', y='Model Name', data=comp_df, ax=axes[0], palette='Blues_r')
    axes[0].set_title('1. R² Score (Higher is Better)', fontsize=12, fontweight='bold')
    axes[0].set_xlim(0, 1.0)
    for p in axes[0].patches:
        axes[0].annotate(f'{p.get_width():.4f}', (p.get_width() + 0.02, p.get_y() + p.get_height()/2.), ha='left', va='center', fontsize=9, fontweight='bold')

    sns.barplot(x='MAE', y='Model Name', data=comp_df, ax=axes[1], palette='Oranges_r')
    axes[1].set_title('2. MAE in INR (Lower is Better)', fontsize=12, fontweight='bold')
    axes[1].set_ylabel('')
    for p in axes[1].patches:
        axes[1].annotate(f'INR {p.get_width():,.0f}', (p.get_width() + 200, p.get_y() + p.get_height()/2.), ha='left', va='center', fontsize=9, fontweight='bold')

    sns.barplot(x='RMSE', y='Model Name', data=comp_df, ax=axes[2], palette='Reds_r')
    axes[2].set_title('3. RMSE in INR (Lower is Better)', fontsize=12, fontweight='bold')
    axes[2].set_ylabel('')
    for p in axes[2].patches:
        axes[2].annotate(f'INR {p.get_width():,.0f}', (p.get_width() + 300, p.get_y() + p.get_height()/2.), ha='left', va='center', fontsize=9, fontweight='bold')

    plt.suptitle('Figure 16: Comprehensive Multi-Metric Model Performance Comparison', fontsize=14, fontweight='bold', y=1.03)
    plt.tight_layout()
    plt.savefig(os.path.join(graphs_dir, "model_performance_comparison.png"), dpi=300)
    plt.close()

    print(f"      Saved all 4 model comparison charts to {graphs_dir}/")
    return best_pipe


def predict_house_rent(best_pipe, city, bhk, size_sqft, bathrooms, floor_level, total_floors,
                       area_type='Super Area', furnishing='Semi-Furnished',
                       tenant_pref='Bachelors/Family', contact='Contact Owner',
                       locality=None):
    """
    Accepts property details, validates inputs, feeds through trained pipeline,
    and returns formatted predicted monthly rent.
    """
    if size_sqft <= 0:
        raise ValueError("Property size must be strictly positive (> 0 sq. ft.).")
    if bhk <= 0:
        raise ValueError("BHK must be at least 1.")
    if bathrooms <= 0:
        raise ValueError("Bathroom count must be at least 1.")
    if floor_level > total_floors and floor_level > 0:
        raise ValueError(f"Floor level ({floor_level}) cannot exceed total building floors ({total_floors}).")

    valid_cities = ['Bangalore', 'Chennai', 'Delhi', 'Hyderabad', 'Kolkata', 'Mumbai']
    if city not in valid_cities:
        raise ValueError(f"Invalid city '{city}'. Must be one of: {valid_cities}")

    size_per_bhk = size_sqft / bhk
    bath_to_bhk = bathrooms / bhk

    input_df = pd.DataFrame([{
        'BHK': bhk,
        'Size': size_sqft,
        'Bathroom': bathrooms,
        'Floor_Level': floor_level,
        'Total_Floors': total_floors,
        'Size_per_BHK': size_per_bhk,
        'Bathroom_to_BHK': bath_to_bhk,
        'City': city,
        'Furnishing Status': furnishing,
        'Tenant Preferred': tenant_pref,
        'Area Type': area_type,
        'Point of Contact': contact
    }])

    pred_log = best_pipe.predict(input_df)[0]
    pred_rent = np.expm1(pred_log)

    print("=" * 80)
    print(f"Predicted Monthly House Rent: INR {pred_rent:,.0f}")
    print(f"Selected Model: Random Forest Regressor")
    print(f"Inputs: {bhk} BHK | {size_sqft} sqft | {bathrooms} Baths | Floor {floor_level}/{total_floors} | {city} | {furnishing}")
    if locality:
        print(f"Locality: {locality} (City-level geographic index applied)")
    print("Notice: This result is an estimated rent based on trained machine learning patterns, not a guaranteed market price.")
    print("=" * 80)
    return pred_rent


def main():
    print("=" * 80)
    print(" HOUSE RENTAL PRICE PREDICTION USING MACHINE LEARNING")
    print(" Full Academic ML Execution Pipeline")
    print("=" * 80)

    df_clean = load_and_preprocess("dataset/House_Rent_Dataset.csv")
    generate_all_visualizations(df_clean, "outputs/graphs")
    best_pipe = train_and_benchmark(df_clean, "outputs", "models")

    print("\n[5/5] Real-Time Sample Predictions Demonstration (PROMPT 7):")
    predict_house_rent(best_pipe, city='Bangalore', bhk=2, size_sqft=1100, bathrooms=2,
                       floor_level=3, total_floors=8, furnishing='Semi-Furnished', locality='Koramangala')
    predict_house_rent(best_pipe, city='Mumbai', bhk=3, size_sqft=1600, bathrooms=3,
                       floor_level=14, total_floors=25, furnishing='Furnished', locality='Bandra West')
    predict_house_rent(best_pipe, city='Kolkata', bhk=1, size_sqft=500, bathrooms=1,
                       floor_level=0, total_floors=3, furnishing='Unfurnished', locality='Dumdum')

    print("\nComplete execution finished successfully! All assets and models generated.")


if __name__ == "__main__":
    main()
